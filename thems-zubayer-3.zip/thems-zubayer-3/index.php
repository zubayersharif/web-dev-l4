<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="./assest/css/bootstrap.min.css">
    <?php wp_head(); ?>
</head>
<body>
    <header class="cont">
        <div class="row toper">
            <div class="col-lg-6 topber_left">
                <p>বাংলাদেশ জাতীয় তথ্য বাতায়ন</p>
            </div>
            <div class="col-lg-6 topber_right text-end">
                ৪ অগ্রহায়ণ, ১৪২৯ | <a href="">English</a>
            </div>
        </div>
    </header>
    <section>
        <div class="cont logo">
            <div class="row">
                <div class="col-lg-5 logo_left">
                    <a href="">
                      <?php the_custom_logo(); ?>
                      <img src="./assest/images/header/logo_bn.png" alt=""></a>
                </div>
                <div class="col-lg-5 logo_search">
                    <input type="text" placeholder="খুঁজুন ">
                    <button>অনুসন্ধান </button>
                </div>
                <div class="col-lg-2 logo_right d-flex justify-content-end">
                    <div class="logo_right1">
                        <a href=""><img src="./assest/images/header/a2i-logo-footer.png" alt=""></a>
                    </div>
                    <div class="logo_right2">
                        <p>সাথে থাকুন:</p>
                        <a href=""><img src="./assest/images/header/facebook-icon.png" alt=""></a>
                        <a href=""><img src="./assest/images/header/twitter-blue-icon.png" alt=""></a>
                        <a href=""><img src="./assest/images/header/youtube-icon.png" alt=""></a>
                        <a href=""><img src="./assest/images/header/gplus-icon.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="cont">
        <div class="row menu_main">
            <nav class="navbar navbar-expand-lg bg-light">
                <div class="container-fluid">
                  
                  <div class="collapse navbar-collapse" id="navbarNav">
                    <?php wp_nav_menu(array(
                      'theme_location'=>'Main_Menu',
                      'menu_class'=>'navbar-nav menu_top'
                    ) ) ?>
                    <!-- <ul class="navbar-nav">
                      <li class="nav-item">
                        <a class="nav-link href="#">হোম</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">বাংলাদেশ সম্পর্কিত</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">ই-সেবাসমূহ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link ">সেবাখাত</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link ">ব্যবসা-বাণিজ্য</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link"> বৈদেশিক বিনিয়োগ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link ">আইন-বিধি</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link ">তথ্য বাতায়ন</a>
                      </li>
                    </ul> -->
                  </div>
                </div>
              </nav>
        </div>
    </section>
    <section class="cont">
        <div class="row hero">
            <div class="col-lg-8 hero_main">
                <div class="banner">
                    <a href="">
                      <?php dynamic_sidebar('banner'); ?>
                     </a>
                </div>
                <div class="slider">
                    <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
                        <div class="carousel-inner">
                        <?php while(have_posts()){the_post(); ?>
                          <div class="carousel-item active">
                          <!-- <?php dynamic_sidebar('slider'); ?> -->
                            <img src="./assest/images/slider/333_gov.png" class="d-block w-100" alt="...">
                          </div>
                          <?php the_title(); }?>
                          <!-- <div class="carousel-item">
                            <img src="./assest/images/slider/our_pride.png" class="d-block w-100" alt="...">
                          </div>
                          <div class="carousel-item">
                            <img src="./assest/images/slider/pmobanner.jpg" class="d-block w-100" alt="...">
                          </div> -->
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
                          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                          <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
                          <span class="carousel-control-next-icon" aria-hidden="true"></span>
                          <span class="visually-hidden">Next</span>
                        </button>
                      </div>

                </div>
                <div class="tab">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                          <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">জনপ্রিয় সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                          <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">নতুন সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                          <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">মোবাইল সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                          <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false">দপ্তর ভিত্তিক সেবা</button>
                        </li>
                        <li class="nav-item" role="presentation">
                          <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false">সকল ই-সেবা</button>
                        </li>
                      </ul>
                      <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                            <div class="row">
                            <div class="col-lg-2">
                                
                                <a href=""><img src="./assest/images/tab/agriculture.png" alt=""></a>
                                <p>কৃষি</p>
                            </div>
                            <div class="col-lg-2">
                                <a href=""><img src="./assest/images/tab/call_center.png" alt=""></a>
                                <p>কল সেন্টার
                                </p>
                            </div>
                            <div class="col-lg-2">
                                <a href=""><img src="./assest/images/tab/agriculture.png" alt=""></a>
                                <p>মৎস্য ও প্রাণী
                                </p>
                            </div>
                            <div class="col-lg-2">
                                <a href=""><img src="./assest/images/tab/agriculture.png" alt=""></a>
                                <p>মোবাইল সেবা

                                </p>
                            </div>
                        </div> 

                        </div>
                        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                            <div class="row">
                                <div class="col-lg-2">
                                    <a href=""><img src="./assest/images/tab/call_center.png" alt=""></a>
                                    <p>কল সেন্টার
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
                            <div class="col-lg-2">
                                <a href=""><img src="./assest/images/tab/agriculture.png" alt=""></a>
                                <p>মৎস্য ও প্রাণী
                                </p>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">
                            <div class="col-lg-2">
                                <a href=""><img src="./assest/images/tab/agriculture.png" alt=""></a>
                                <p>মোবাইল সেবা</p>
                            </div>
                        
                        </div>
                      </div>
                </div>
                <div class="list mt-4 ps-2">
                    <h1>উদ্যোগ</h1>
                    <?php dynamic_sidebar('list'); ?>
                    <!-- <ul>
                        <li><a href=""> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a></li>
                        <li><a href="">  বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a></li>
                        <li><a href=""> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a></li>
                        <li><a href=""> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a></li>
                        <li><a href=""> বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০)</a></li>
                      </ul> -->
                </div>
            </div>
            <div class="col-lg-4 hero_main">
                <div class="sidebar_img">
                    <a href="">
                      <?php dynamic_sidebar('sideimg'); ?>
                      <!-- <img src="./assest/images/sidebar/bangladesh-portal--batton-bangla.png" class="d-block w-100 mb-2" alt=""> -->
                    </a>
                    
                    <!-- <h1>ডেঙ্গু প্রতিরোধে করণীয়</h1>
                  <a href=""><img src="./assest/images/sidebar/dengu.jpg" class="d-block w-100 mb-2" alt=""></a>
                  <a href=""><img src="./assest/images/sidebar/discount_bn.jpg" class="d-block w-100 mb-2" alt=""></a>
                  <h1>মাস্ক পরুন সেবা নিন</h1>
                  <a href=""><img src="./assest/images/sidebar/mask-bd-portal (1).jpg" class="d-block w-100 mb-2" alt=""></a>
                  <h4>সকল বাতায়ন</h4> -->
                <form action="">
                  <select name="" id="">
                    <option value="">ওয়েব সাইট বাছাই করুন</option>
                    <option value="">ঢাকা বিভাগ</option>
                    <option value="">রাজশাহী বিভাগ</option>
                    <option value="">ঢাকা বিভাগ</option>
                  </select>
                  <button>চলুন</button>
                </form>
                </div>
                <div class="sidebar_video">
                  <h5>মুজিব১০০ আ্যাপ</h5>
                  <?php dynamic_sidebar('sidevideo'); ?>
                  

                </div>
            
        </div>
    </section>
    <footer class="cont">
        <div class="row footer_main">
        <?php dynamic_sidebar('footerimg'); ?>
          <img src="./assest/images/footer/footer_top_bg.png" alt="">
        </div>
        <div class="row footer_bottom">
          <div class="col-lg-8 fb_left">
            <nav class="navbar navbar-expand-lg bg-light">
              <div class="">
                
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <?php wp_nav_menu(array(
                      'theme_location'=>'FM',
                      'menu_class'=>'navbar-nav menu_top'
                    ) ) ?>
                  <!-- <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href="#">গোপনীয়তার নীতিমালা</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">ব্যবহারের শর্তাবলি</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">সার্বিক সহযোগিতায়</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#">সেবাখাত</a>
                    </li> 
                  </ul> -->
  
                </div>
              </div>
            </nav>
          </div>
          <div class="col-4 fb_right text-end">
            <p>পরিকল্পনা ও বাস্তবায়নে: এটুআই, মন্ত্রিপরিষদ বিভাগ, বিসিসি, বেসিস, ডিওআইসিটি</p>
            <img src="./assest/images/footer/np-logo-set.png" alt="">
          </div>
        </div>
      </footer>

    <?php wp_footer(); ?>               
    
    <script src="./myscript.js"></script>

    <!-- <?php
    $mark= '50';
    if($mark >=40){
      echo 'Pass';
    }else{
      echo 'Fail';
    } 
    ?> -->
<section class="cont pt-5 pb-5">
  <div class="row">
    <div class="col-sm-4">
      <?php
      $sum=0;
      for($i=0;$i<=10;$i++){
        $sum=$sum+$i;
        echo $sum.'<br>';
      }
      
      ?>
    </div>
    <div class="col-sm-4 mid"></div>
    <div class="col-sm-4 ">
      <?php
      $p=50;
      echo ($p>=40)?'<h1>pass</h1>':'<h1>Fail</h1>';
      ?>


      <?php 
      $zs=0;
      while($zs<=18){
        echo $zs.'<br>';
        $zs=$zs+2;
      }
      
      ?>
    </div>
  </div>
</section>
    
</body>
</html>