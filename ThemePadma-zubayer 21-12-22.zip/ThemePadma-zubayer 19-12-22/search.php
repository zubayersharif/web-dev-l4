<h1>Under develop</h1>
<?php get_header(); ?>
<section class="container search">
      <div class="row">
        <div class="col-sm-8">l</div>
        <div class="col-sm-4">
          <form action="">
            <input type="text" value="<?= get_search_query(); ?>" name="s">
            <button>Search</button>
          </form>
        </div>
      </div>
    </section>
<?php get_header();?>