
     <footer class='container-fluid mt-5 bg-info'>
        <div class="row">
          <div class="col-sm-6">
          <?php dynamic_sidebar('footertext1'); ?>
          </div>
          <div class="col-sm-6">
          <?php dynamic_sidebar('footertext2'); ?>
          </div>
        </div>
      </div>
      </footer>
      <?php wp_footer(); ?>
</body>
</html>