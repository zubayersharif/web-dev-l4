<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-boot', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );


add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo', array(
    'height' => 480,
    'width'  => 720,
) );
add_theme_support( 'post-thumbnails' );

register_sidebar( array(
    'name'          => 'BD Logo',
	'id'            => 'bdlogo',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Hero Title',
	'id'            => 'herotitle',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_nav_menus( array(
    'PM'=>'primary_menu'
) );
register_sidebar( array(
    'name'          => 'Card Img 1',
	'id'            => 'cardimg1',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Card Img 2',
	'id'            => 'cardimg2',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Card Img 3',
	'id'            => 'cardimg3',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'photo Img 1',
	'id'            => 'photoimg1',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'photo Img 2',
	'id'            => 'photoimg2',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'photo Img 3',
	'id'            => 'photoimg3',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Photo Bottom Img 1',
	'id'            => 'photobottomimg1',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Photo Bottom Img 2',
	'id'            => 'photobottomimg2',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Photo Bottom Img 3',
	'id'            => 'photobottomimg3',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Photo Bottom Img 4',
	'id'            => 'photobottomimg4',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Footer Top Left',
	'id'            => 'ftleft',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Footer Top Right',
	'id'            => 'ftright',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Footer Bottom Left',
	'id'            => 'fbleft',
    'before_widget' => '',
    'after_widget'  => '',
) );
register_sidebar( array(
    'name'          => 'Footer Bottom Right',
	'id'            => 'fbright',
    'before_widget' => '',
    'after_widget'  => '',
) );



?>