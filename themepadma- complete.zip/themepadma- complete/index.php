<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body>
    <!-- slider -->
   <header class="container-fluid slider">
    <?php 
    $qry1 =new WP_Query([
        'post_type'=>'post',
        'category_name'=>'slider'

    ]);
    ?>
   <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <?php
    $x=0;
    while($qry1->have_posts()){$qry1->the_post();
    $x++;
    ?>
    <div class="carousel-item <?=($x==1)?'active':''?>">
    <?php the_post_thumbnail();?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php }?>
   
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
   </header>
   <!-- logo -->
   <section class="container-fluid logo">
        <div class="row">
            <div class="col-sm-6 logo_left">
                <?php the_custom_logo(); ?>
            </div>
            <div class="col-sm-6 logo_right">
                <?php dynamic_sidebar('bdlogo'); ?>
            </div>
        </div>
    </section>
    <!-- menu -->
    <section class="container-fluid menu">
    <?php wp_nav_menu([
                'theme_location'=>'PM',
                'menu_class'=>'menu_1 navber-nav'
            ]) ?>
    </section>
    <!-- hero -->
    <section class="container hero">
        <div class="row hero_top">
            <?php dynamic_sidebar('herotitle'); ?>
        </div>
        <div class="row hero_bottom-1">
        <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                <?php dynamic_sidebar('cardimg1'); ?>
            </div>
        </div>
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
                <?php dynamic_sidebar('cardimg2'); ?>
            </div>
       
        </div>
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
                <?php dynamic_sidebar('cardimg3'); ?>
        </div>
        </div>
        
        </div>
    </section>
    <!-- photo -->
    <section class="container">
        <div class="row">
            <div class="col-sm-5">
                <?php dynamic_sidebar('photoimg1') ?>
            </div>
            <div class="col-sm-2">
            <?php dynamic_sidebar('photoimg2') ?>
            </div>
            <div class="col-sm-5">
            <?php dynamic_sidebar('photoimg3') ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
            <?php dynamic_sidebar('photobottomimg1') ?>
            </div>
            <div class="col-sm-3">
            <?php dynamic_sidebar('photobottomimg2') ?>
            </div>
            <div class="col-sm-3">
            <?php dynamic_sidebar('photobottomimg3') ?>
            </div>
            <div class="col-sm-3">
            <?php dynamic_sidebar('photobottomimg4') ?>
            </div>
        </div>
    </section>
    <!-- slider2 -->
    </section>
    <!-- slider-2 -->
    <header class="container-fluid slider">
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <?php
        $qry2 = new WP_Query([
            'post_type'=>'post',
            'category_name'=>'slider'
        ]);
        ?>
  <div class="carousel-inner">
    <?php 
    $x=0;
    while($qry2->have_posts()){$qry2->the_post();
    $x++;
    ?>
    <div class="carousel-item <?=  ($x==1)?'active':''?>">
    <?php the_title(); ?>

      <!-- <img src="..." class="d-block w-100" alt="..."> -->
      
    </div>
    <?php }?>
    
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    </header>
    <!-- footer -->
    <footer class="container-fluid mt-5 foot">
        <div class="container">
            <div class="row ft">
                <div class="col-sm-8 ft_left">
                    <?php dynamic_sidebar('ftleft'); ?>
                </div>
                <div class="col-sm-4 ft_right">
                <?php dynamic_sidebar('ftright'); ?>
                </div>
            </div>
            <div class="row fb">
                <div class="col-sm-6 fb_left">
                <?php dynamic_sidebar('fbleft'); ?>
                </div>
                <div class="col-sm-6 fb_right">
                <?php dynamic_sidebar('fbright'); ?>
                </div>
            </div>
        </div>
     
    </footer>







<?php wp_footer(); ?>
    
</body>
</html>